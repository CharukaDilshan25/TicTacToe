package com.example.newgame



import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class Register : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val continueBtn1 = findViewById<Button>(R.id.continueBtn1)
        continueBtn1.setOnClickListener {
            val playerOneName = findViewById<EditText>(R.id.editTextText).text.toString()
            val playerTwoName = findViewById<EditText>(R.id.editTextText2).text.toString()

            val intent = Intent(this, MainActivity::class.java)
            intent.putExtra("PLAYER_ONE_NAME", playerOneName)
            intent.putExtra("PLAYER_TWO_NAME", playerTwoName)
            startActivity(intent)
            finish()
        }
    }
}